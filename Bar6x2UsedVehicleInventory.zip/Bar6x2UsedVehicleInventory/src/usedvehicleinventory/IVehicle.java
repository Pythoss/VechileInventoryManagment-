package usedvehicleinventory;

public interface IVehicle {
    public void assignType();
}
