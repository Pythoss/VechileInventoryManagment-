
package usedvehicleinventory;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public abstract class Vehicle implements IVehicle {
    protected StringProperty id = new SimpleStringProperty("");
    protected StringProperty type = new SimpleStringProperty("");;
    protected StringProperty make = new SimpleStringProperty("");;
    protected StringProperty model = new SimpleStringProperty("");;
    protected StringProperty year = new SimpleStringProperty("");;
    protected IntegerProperty odometer = new SimpleIntegerProperty(0);;
    protected StringProperty condition = new SimpleStringProperty("");;
    protected IntegerProperty price = new SimpleIntegerProperty(0);;
    
    public Vehicle() {
       }
   
    public String getId() {
        return id.get();
    }

    public void setId(String id) {
       this.id = new SimpleStringProperty(id);
    }

    public StringProperty idProperty() {
        return id;
    }
    
    public String getType(){
        return type.get();
    }

    public void setType(String type) {
        if(type != null){
           this.type = new SimpleStringProperty(type);
        } else {
            this.type = new SimpleStringProperty("Car");// default
        }
    }

    public StringProperty typeProperty() {
        return type;
    }
    
    public String getMake(){
        return make.get();
    }

    public void setMake(String make) {
        this.make = new SimpleStringProperty(make);
    }

    public StringProperty makeProperty() {
        return make;
    }
    
    public String getModel(){
        return model.get();
    }

    public void setModel(String model) {
        this.model= new SimpleStringProperty(model);
    }

    public StringProperty modelProperty() {
        return model;
    }
    
    public String getYear(){
        return year.get();
    }

    public void setYear(String year) {
        this.year = new SimpleStringProperty(year);
    }

    public StringProperty yearProperty() {
        return year;
    }
    
     public String getCondition(){
        return condition.get();
    }

    public void setCondition(String condition) {
        this.condition = new SimpleStringProperty(condition);
    }

    public StringProperty conditionProperty() {
        return condition;
    }
    
     public int getOdometer(){
        return odometer.get();
    }

    public void setOdometer(int odometer) {
        this.odometer= new SimpleIntegerProperty(odometer);
    }

    public IntegerProperty odometerProperty() {
        return odometer;
    }
    
     public int getPrice(){
        return price.get();
    }

    public void setPrice(int price) {
        this.price = new SimpleIntegerProperty(price);
    }

    public IntegerProperty priceProperty() {
        return price;
    }
}
