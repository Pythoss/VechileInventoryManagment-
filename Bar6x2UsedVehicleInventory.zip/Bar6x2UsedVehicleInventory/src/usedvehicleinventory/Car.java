package usedvehicleinventory;

public class Car extends Vehicle {
//    public Car(String id){
//        super(id);
//        assignType();
//    }
    
    public Car(){
     }
    
    @Override
    public void assignType() {
        setType("Car");
    }
    
}
