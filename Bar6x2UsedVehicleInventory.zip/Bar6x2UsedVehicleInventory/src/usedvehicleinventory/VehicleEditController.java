
package usedvehicleinventory;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class VehicleEditController {
    @FXML
    private TextField idField;
    @FXML
    private TextField typeField;
    @FXML
    private TextField makeField;
    @FXML
    private TextField modelField;
    @FXML
    private TextField yearField;
    @FXML
    private TextField odometerField;
    @FXML
    private TextField conditionField;
    @FXML
    private TextField priceField;

    private Stage editStage;
    private Vehicle vehicle;
    private boolean saveChange = false;

   
    @FXML
    private void initialize() {
    }

  
    public void setEditStage(Stage editStage) {
        this.editStage = editStage;
    }

    // Sets the vehicle to be edited.
        public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
        if (null != vehicle.getId()){
            idField.setText(vehicle.getId());
            typeField.setText(vehicle.getType());
            makeField.setText(vehicle.getMake());
            modelField.setText(vehicle.getModel());
            yearField.setText(vehicle.getYear());
            yearField.setPromptText("YYYY");
            odometerField.setText(Integer.toString(vehicle.getOdometer()));
            odometerField.setPromptText("numeric 99999");
            conditionField.setText(vehicle.getCondition());
            priceField.setText(Integer.toString(vehicle.getPrice()));
        }
    }

  
     // Returns true if the user clicked Save Vehicle Changes, false otherwise.
   
    public boolean isSaveChangeClicked() {
        return saveChange;
    }

    @FXML
    private void handleSaveChanges() {
  //      if (isInputValid()) -- to do{
            vehicle.setId(idField.getText());
            vehicle.setType(typeField.getText());
            vehicle.setMake(makeField.getText());
            vehicle.setModel(modelField.getText());
            vehicle.setYear(yearField.getText());
            vehicle.setOdometer(Integer.parseInt(odometerField.getText()));
            vehicle.setCondition(conditionField.getText());
            vehicle.setPrice(Integer.parseInt(priceField.getText()));
            saveChange = true;
            editStage.close();
        }
   

   //Called when user clicks cancel
    @FXML
    private void handleCancel() {
        editStage.close();
    }
    
}
