package usedvehicleinventory;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import javafx.application.Application;
import java.io.IOException;
import java.io.InputStreamReader;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Bar6x2ApplicationFXMain extends Application {
       
    private Stage primaryStage;
    private BorderPane rootLayout;
    private ObservableList<Vehicle> vehicleData = FXCollections.observableArrayList();

    public Bar6x2ApplicationFXMain(){
       initialize();
     }

   
    public ObservableList<Vehicle> getVehicleData() {
        return vehicleData;
    }
   
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Vehicle Inventory Application");

        initRootLayout();

        showVehicleOverview();
    }

    /**
     * Initializes the root layout.
     */
     @SuppressWarnings("CallToPrintStackTrace")
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Bar6x2ApplicationFXMain.class.getResource("RootLayoutFXML.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public void showVehicleOverview() {
        try {
            // Load vehicle overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Bar6x2ApplicationFXMain.class.getResource("VehicleOverviewFXML.fxml"));
            AnchorPane vehicleOverview = (AnchorPane) loader.load();

            // Set vehicle overview into the center of root layout.
            rootLayout.setCenter(vehicleOverview);
            
             // Give the controller access to the main app.
            UsedVehicleInventoryController controller = loader.getController();
            controller.setMainApp(this);
              
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 
    public Stage getPrimaryStage() {
        return primaryStage;
    }
    
    public boolean showVehicleEditForm(Vehicle vehicle) {
    try {
        // Load the fxml file and create a new stage for the popup dialog.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Bar6x2ApplicationFXMain.class.getResource("VehicleEditFormFXML.fxml"));
        AnchorPane page = (AnchorPane) loader.load();

        // Create the dialog Stage.
        Stage editStage = new Stage();
        editStage.setTitle("Edit Vehicle");
        editStage.initModality(Modality.WINDOW_MODAL);
        editStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        editStage.setScene(scene);

        // Set the vehicle into the controller.
        VehicleEditController controller = loader.getController();
        controller.setEditStage(editStage);
        controller.setVehicle(vehicle);

        // Show the dialog and wait until the user closes it
        editStage.showAndWait();

        return controller.isSaveChangeClicked();
    } catch (IOException e) {
        System.err.println("Error: " + e.getMessage());
        return false;
    }
}

    public static void main(String[] args) {
        launch(args);
    }

    public void initialize(){

       try{
    String workingDirectory = System.getProperty("user.dir");
    FileInputStream fstream = new FileInputStream(workingDirectory + "\\src\\csvfiles\\vehicledata.txt");
  // Get the object of DataInputStream
     DataInputStream in = new DataInputStream(fstream);
    BufferedReader br = new BufferedReader(new InputStreamReader(in));
     String strLine = "";
  //Read File Line By Line
     while ((strLine = br.readLine()) != null)   {
         Vehicle vehicle = createVehicle(strLine);
              if (vehicle != null){
                  vehicleData.add(vehicle);
              }
  }
  //Close the input stream
  in.close();
    }catch (Exception e){//Catch exception if any
     System.err.println("Error: " + e.getMessage());
    }
  }
    
    public Vehicle createVehicle(String data) {
        Vehicle value = null;
        String [] tokens = data.split("\\|");// need to escape the |
      
        if ((tokens != null) && (tokens.length == 8)) {
           if ("Car".equals(tokens[1])){
               value = new Car();
           } else if ("Truck".equals(tokens[1])){
               value = new Truck();
           } else {
               return value;
           }
         
            value.setId(tokens[0]);
            value.assignType();
            value.setMake(tokens[2]);
            value.setModel(tokens[3]);
            value.setYear(tokens[4]);
            int odometer = 0;
            try {
            odometer = Integer.parseInt(tokens[5]);
            }
            catch (NumberFormatException e){
             // do nothing odometer is set to 0         
            }
            value.setOdometer(odometer);
            value.setCondition(tokens[6]);
            int price = 0;
            try {
                 price = Integer.parseInt(tokens[7]);
            } catch (NumberFormatException e){
                
            }
            value.setPrice(price);
            
        }
        return value;
    }
    
    @FXML
    public void handleAbout() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Bar6x2ApplicationFXMain.class.getResource("AboutFXML.fxml"));
            AnchorPane about;
            about = (AnchorPane) loader.load();
            
            Stage aboutStage = new Stage();
            aboutStage.setTitle("About the Application");
            aboutStage.initModality(Modality.WINDOW_MODAL);
            aboutStage.initOwner(primaryStage);
            Scene scene = new Scene(about);
            aboutStage.setScene(scene);
            aboutStage.showAndWait();
        } catch (IOException ex) {
            System.err.println("Error: " + ex.getMessage());
        }
            
        
       
        
    }
}
    

