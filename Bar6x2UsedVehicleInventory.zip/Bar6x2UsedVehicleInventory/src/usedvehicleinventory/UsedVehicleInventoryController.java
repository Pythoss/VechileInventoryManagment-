
package usedvehicleinventory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;


public class UsedVehicleInventoryController {
    
    @FXML
    private TableView<Vehicle> vehicleTable;
    @FXML
    private TableColumn<Vehicle, String> idColumn;
    @FXML
    private TableColumn<Vehicle, String> typeColumn;

    @FXML
    private Label idLabel;
    @FXML
    private Label typeLabel;
    @FXML
    private Label makeLabel;
    @FXML
    private Label modelLabel;
    @FXML
    private Label yearLabel;
    @FXML
    private Label odometerLabel;
    @FXML
    private Label conditionLabel;
    @FXML
    private Label priceLabel;

    // Reference to the main application.
    private Bar6x2ApplicationFXMain mainApp;

    public UsedVehicleInventoryController() {
    }
   
    // Initializes the controller class. This method is automatically called
    // after the fxml file has been loaded.
     
    @FXML
    private void initialize() {
        // Initialize the vehicle table on the left with the two columns.
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        typeColumn.setCellValueFactory(cellData -> cellData.getValue().typeProperty());
        
        // Clear vehicle details.
        showVehicleDetails(null);

    // Listen for selection changes and show the vehicle details on the
    // right when selected
    vehicleTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showVehicleDetails(newValue));
    }

    /**
     * Is called by the main application to give a reference back to itself.
    */
    public void setMainApp(Bar6x2ApplicationFXMain mainApp) {
        this.mainApp = mainApp;

        // Add observable list vehicle data to the table
        vehicleTable.setItems(mainApp.getVehicleData());
    }

    private void showVehicleDetails(Vehicle vehicle) {
    if (vehicle != null) {
        // Fill the labels with info from the vehicle object.
        idLabel.setText(vehicle.getId());
        typeLabel.setText(vehicle.getType());
        makeLabel.setText(vehicle.getMake());
        modelLabel.setText(vehicle.getModel());
        yearLabel.setText(vehicle.getYear());
        odometerLabel.setText(Integer.toString(vehicle.getOdometer()));
        conditionLabel.setText(vehicle.getCondition());
        priceLabel.setText(Integer.toString(vehicle.getPrice()));
      
    } else {
        // Vehicle is null, clear the text.
        idLabel.setText("");
        typeLabel.setText("");
        makeLabel.setText("");
        modelLabel.setText("");
        yearLabel.setText("");
        conditionLabel.setText("");
        priceLabel.setText("");
    }
}
    
    @FXML
private void handleDeleteVehicle() {
    int selectedIndex = vehicleTable.getSelectionModel().getSelectedIndex();
    if (selectedIndex >= 0) {
        vehicleTable.getItems().remove(selectedIndex);
    } else {
        Alert alert = new Alert(AlertType.WARNING);
        alert.initOwner(mainApp.getPrimaryStage());
        alert.setTitle("Warning");
        alert.setHeaderText("No Vehicle Selected");
        if(vehicleTable.getItems().isEmpty()){
            alert.setContentText("There are no vehicles to delete");
        } else {
        alert.setContentText("Please select the vehicle in the table you wish to delete.");
        }
        alert.showAndWait();
   }
}

@FXML
@SuppressWarnings("CallToPrintStackTrace")
private void handleSaveVehicles(){
    FileWriter fw = null;
        try {
            String workingDirectory = System.getProperty("user.dir");
            workingDirectory = workingDirectory + "\\src\\csvfiles";
            Path path = Paths.get(workingDirectory, "temp.txt");
            // Creates file 'temp.txt' in the specified directory
            // used for testing. vehicledata.txt would be overwritten
            // when not testing
            if (!Files.exists(path)){
                try {
                    Files.createFile(path);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }  
            fw = new FileWriter(path.toAbsolutePath().toString(),false);
            BufferedWriter bw = new BufferedWriter(fw);
            for(Vehicle v : vehicleTable.getItems()){
                StringBuilder stringData = new StringBuilder();
                stringData.append(v.getId()).append("|");
                stringData.append(v.getType()).append("|");
                stringData.append(v.getMake()).append("|");
                stringData.append(v.getModel()).append("|");
                stringData.append(v.getYear()).append("|");
                stringData.append(v.getOdometer()).append("|");
                stringData.append(v.getCondition()).append("|");
                stringData.append(v.getPrice());
                
                bw.write(stringData.toString());
                bw.newLine();
                
            } 
            bw.close();
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("Information");
            alert.setHeaderText("Success");
            alert.setContentText("Changes have been saved!");
            alert.showAndWait();
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                fw.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    
}

@FXML
private void handleNewCar() {
     Car tempVehicle = new Car();
     handleNewVehicle(tempVehicle);

}

@FXML
private void handleNewTruck() {
    Truck tempVehicle = new Truck();
    handleNewVehicle(tempVehicle);
}

private void handleNewVehicle(Vehicle tempVehicle) {
  tempVehicle.assignType();
    boolean saveVehicleChanges = mainApp.showVehicleEditForm(tempVehicle);
    if (saveVehicleChanges) {
        mainApp.getVehicleData().add(tempVehicle);
    }  
}

@FXML
private void handleEditVehicle() {
    Vehicle selectedVehicle = vehicleTable.getSelectionModel().getSelectedItem();
    if (selectedVehicle != null) {
        boolean saveChangesClicked = mainApp.showVehicleEditForm(selectedVehicle);
        if (saveChangesClicked) {
            showVehicleDetails(selectedVehicle);
        }

    } else {
        // Nothing selected.
        Alert alert = new Alert(AlertType.WARNING);
        alert.initOwner(mainApp.getPrimaryStage());
        alert.setTitle("No Selection");
        alert.setHeaderText("No Vehicle Selected");
        alert.setContentText("Please select a vehicle in the table.");

        alert.showAndWait();
    }
}
 
}
    
