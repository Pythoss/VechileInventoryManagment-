
package usedvehicleinventory;

public class Truck extends Vehicle {

    public Truck(String id) {
        super(id);
        assignType();
    }
    
    public Truck(){
    }

    @Override
    public void assignType() {
        setType("Truck");
    }
    
}
