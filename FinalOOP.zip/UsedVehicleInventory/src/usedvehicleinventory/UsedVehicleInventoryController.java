
package usedvehicleinventory;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;


public class UsedVehicleInventoryController {
    
    @FXML
    private TableView<Vehicle> vehicleTable;
    @FXML
    private TableColumn<Vehicle, String> idColumn;
    @FXML
    private TableColumn<Vehicle, String> typeColumn;

    @FXML
    private Label idLabel;
    @FXML
    private Label typeLabel;
    @FXML
    private Label makeLabel;
    @FXML
    private Label modelLabel;
    @FXML
    private Label yearLabel;
    @FXML
    private Label odometerLabel;
    @FXML
    private Label conditionLabel;
    @FXML
    private Label priceLabel;

    // Reference to the main application.
    private ApplicationFXMain mainApp;

    public UsedVehicleInventoryController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        // Initialize the vehicle table on the left with the two columns.
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        typeColumn.setCellValueFactory(cellData -> cellData.getValue().typeProperty());
        
        // Clear vehicle details.
        showVehicleDetails(null);

    // Listen for selection changes and show the vehicle details on the
    // right when selected
    vehicleTable.getSelectionModel().selectedItemProperty().addListener(
            (observable, oldValue, newValue) -> showVehicleDetails(newValue));
    }

    /**
     * Is called by the main application to give a reference back to itself.
    */
    public void setMainApp(ApplicationFXMain mainApp) {
        this.mainApp = mainApp;

        // Add observable list vehicle data to the table
        vehicleTable.setItems(mainApp.getVehicleData());
    }

    private void showVehicleDetails(Vehicle vehicle) {
    if (vehicle != null) {
        // Fill the labels with info from the vehicle object.
        idLabel.setText(vehicle.getId());
        typeLabel.setText(vehicle.getType());
        makeLabel.setText(vehicle.getMake());
        modelLabel.setText(vehicle.getModel());
        yearLabel.setText(vehicle.getYear());
        odometerLabel.setText(Integer.toString(vehicle.getOdometer()));
        conditionLabel.setText(vehicle.getCondition());
        priceLabel.setText(Integer.toString(vehicle.getPrice()));
      
    } else {
        // Vehicle is null, clear the text.
        idLabel.setText("");
        typeLabel.setText("");
        makeLabel.setText("");
        modelLabel.setText("");
        yearLabel.setText("");
        conditionLabel.setText("");
        priceLabel.setText("");
    }
}
    
    @FXML
private void handleDeleteVehicle() {
    int selectedIndex = vehicleTable.getSelectionModel().getSelectedIndex();
    if (selectedIndex >= 0) {
        vehicleTable.getItems().remove(selectedIndex);
    } else {
        Alert alert = new Alert(AlertType.WARNING);
        alert.initOwner(mainApp.getPrimaryStage());
        alert.setTitle("Warning");
        alert.setHeaderText("No Vehicle Selected");
        if(vehicleTable.getItems().isEmpty()){
            alert.setContentText("There are no vehicles to delete");
        } else {
        alert.setContentText("Please select the vehicle in the table who wish to delete.");
        }
        alert.showAndWait();
   }
}
 
}
    
