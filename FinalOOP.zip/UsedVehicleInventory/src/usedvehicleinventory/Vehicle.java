
package usedvehicleinventory;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public abstract class Vehicle implements IVehicle {
    protected StringProperty id;
    protected StringProperty type;
    protected StringProperty make;
    protected StringProperty model;
    protected StringProperty year;
    protected IntegerProperty odometer;
    protected StringProperty condition;
    protected IntegerProperty price;
    
    public Vehicle() {
       }

    
    public Vehicle(String id) {
        this.id = new SimpleStringProperty(id);
        this.type = new SimpleStringProperty("Car");
        // Some initial dummy data, just for convenient testing.
        this.make = new SimpleStringProperty("Honda");
        this.model = new SimpleStringProperty("Civic");
        this.year = new SimpleStringProperty("2015");
        this.odometer = new SimpleIntegerProperty(12000);
        this.condition = new SimpleStringProperty("Good");
        this.price = new SimpleIntegerProperty(12345);
    }
    
    public String getId() {
        return id.get();
    }

    public void setId(String id) {
        System.out.println(" id " + id);
        this.id = new SimpleStringProperty(id);
    }

    public StringProperty idProperty() {
        return id;
    }
    
    public String getType(){
        return type.get();
    }

    public void setType(String type) {
        if(type != null){
            System.out.println("type " + type);
       //     this.type.set(type);
              this.type = new SimpleStringProperty(type);
        } else {
            this.type = new SimpleStringProperty("Car");
        }
    }

    public StringProperty typeProperty() {
        return type;
    }
    
    public String getMake(){
        return make.get();
    }

    public void setMake(String make) {
        this.make = new SimpleStringProperty(make);
    }

    public StringProperty makeProperty() {
        return make;
    }
    
    public String getModel(){
        return model.get();
    }

    public void setModel(String model) {
        this.model= new SimpleStringProperty(model);
    }

    public StringProperty modelProperty() {
        return model;
    }
    
    public String getYear(){
        return year.get();
    }

    public void setYear(String year) {
        this.year = new SimpleStringProperty(year);
    }

    public StringProperty yearProperty() {
        return year;
    }
    
     public String getCondition(){
        return condition.get();
    }

    public void setCondition(String condition) {
        this.condition = new SimpleStringProperty(condition);
    }

    public StringProperty conditionProperty() {
        return condition;
    }
    
     public int getOdometer(){
        return odometer.get();
    }

    public void setOdometer(int odometer) {
        this.odometer= new SimpleIntegerProperty(odometer);
    }

    public IntegerProperty odometerProperty() {
        return odometer;
    }
    
     public int getPrice(){
        return price.get();
    }

    public void setPrice(int price) {
        this.price = new SimpleIntegerProperty(price);
    }

    public IntegerProperty priceProperty() {
        return price;
    }
}
