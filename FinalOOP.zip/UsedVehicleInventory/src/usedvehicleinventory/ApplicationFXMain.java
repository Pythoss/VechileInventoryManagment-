package usedvehicleinventory;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import javafx.application.Application;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;

import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class ApplicationFXMain extends Application {
    
    private Stage primaryStage;
    private BorderPane rootLayout;
    private ObservableList<Vehicle> vehicleData = FXCollections.observableArrayList();

    public ApplicationFXMain(){
       initialize();
        // Add some sample data
//        vehicleData.add(new Car("0001"));
//        vehicleData.add(new Car("0002"));
//        vehicleData.add(new Truck("0003"));
//        vehicleData.add(new Truck("0004"));
// 
    }

   
    public ObservableList<Vehicle> getVehicleData() {
        return vehicleData;
    }
   
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("VehicleApplication");

        initRootLayout();

        showVehicleOverview();
    }

    /**
     * Initializes the root layout.
     */
     @SuppressWarnings("CallToPrintStackTrace")
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(ApplicationFXMain.class.getResource("RootLayoutFXML.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Shows the person overview inside the root layout.
     */
     @SuppressWarnings("CallToPrintStackTrace")
    public void showVehicleOverview() {
        try {
            // Load vehicle overview.
            FXMLLoader loader = new FXMLLoader();
      //      loader.setLocation(UsedVehicleInventoryController.class.getResource("VehicleOverviewFXML.fxml"));
              loader.setLocation(ApplicationFXMain.class.getResource("VehicleOverviewFXML.fxml"));
            AnchorPane vehicleOverview = (AnchorPane) loader.load();

            // Set vehicle overview into the center of root layout.
            rootLayout.setCenter(vehicleOverview);
            
             // Give the controller access to the main app.
            UsedVehicleInventoryController controller = loader.getController();
            controller.setMainApp(this);
              
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 
    /**
     * Returns the main stage.
     * @return
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }

//    @Override
//    public void initialize(URL location, ResourceBundle resources) {
    public void initialize(){
       System.out.println("initialize");
       try{
  File file = new File("vehicledata.txt");
  String absolutePath = file.getAbsolutePath();
  Path currentDir = Paths.get(".");
  System.out.println("current dir " + currentDir.toAbsolutePath());
  Path parentDir = Paths.get("..");
  System.out.println("parent dir " + parentDir.toAbsolutePath());
  System.out.println(absolutePath); // C:\\Users\\Beverly\\Documents\\NetBeansProjects\\UsedVehicleInventory
  FileInputStream fstream = new FileInputStream("C:\\Users\\Beverly\\Documents\\NetBeansProjects\\UsedVehicleInventory\\src\\csvfiles\\vehicledata.txt");
  // Get the object of DataInputStream
  DataInputStream in = new DataInputStream(fstream);
  BufferedReader br = new BufferedReader(new InputStreamReader(in));
  String strLine = "";
  //Read File Line By Line
  while ((strLine = br.readLine()) != null)   {
  Vehicle vehicle = createVehicle(strLine);
              if (vehicle != null){
                  vehicleData.add(vehicle);
              }
  }
  //Close the input stream
  in.close();
    }catch (Exception e){//Catch exception if any
     System.err.println("Error: " + e.getMessage());
  }
  }
//}

            
//            //Read the file line by line
//            
//            while ((line = fileReader.readLine()) != null) 
//            {
//                System.out.println("reading");
//              Vehicle vehicle = createVehicle(line);
//              if (vehicle != null){
//                  vehicleData.add(vehicle);
//              }
//            }
//            
//        } catch (FileNotFoundException ex) {
//            ex.printStackTrace();
//        } catch (IOException ex) {
//             ex.printStackTrace();
//        }
//           finally
//        {
//            try {
//                fileReader.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
 
            
  //      }
    
    public Vehicle createVehicle(String data) {
        System.out.println("creating vehicle " + data);
        Vehicle value = null;
        String [] tokens = data.split("\\|");// need to escape the |
      
        System.out.println("tokens size" + tokens.length);
        if ((tokens != null) && (tokens.length == 8)) {
           if ("Car".equals(tokens[1])){
               System.out.println("its a car");
               value = new Car();
           } else if ("Truck".equals(tokens[1])){
               value = new Truck();
           } else {
               return value;
           }
           System.out.println("1" + tokens[0]);
            value.setId(tokens[0]);
             System.out.println("2");
            value.assignType();
             System.out.println("3");
            value.setMake(tokens[2]);
            value.setModel(tokens[3]);
            value.setYear(tokens[4]);
            int odometer = 0;
            try {
            odometer = Integer.parseInt(tokens[5]);
            }
            catch (NumberFormatException e){
                   
            }
            value.setOdometer(odometer);
            value.setCondition(tokens[6]);
            int price = 0;
            try {
                 price = Integer.parseInt(tokens[7]);
            } catch (NumberFormatException e){
                
            }
            value.setPrice(price);
            
        }
        System.out.println("returning value " + (value == null));
        return value;
    }
}
    

